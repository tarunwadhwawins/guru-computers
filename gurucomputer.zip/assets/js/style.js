// <!-- Banner-craousel -->
$(document).ready(function() {
    $('.treatment').owlCarousel({
        items: 1,
        nav: false,
        center: true,
        loop: true,
        margin: 10,
        autoplay: true,
        dots: true,
        dotsData: true,

    })
});